import React from 'react'

import Script from 'dangerous-html/react'

import './footer.css'

const Footer = (props) => {
  return (
    <div className="footer-container1">
      <footer className="footer-wrapper">
        <div className="footer-container">
          <div className="footer-grid">
            <div className="footer-column footer-brand">
              <h2 className="footer-logo">Mohit Sinha</h2>
              <p className="footer-bio section-content">
                Technology professional specializing in Artificial Intelligence
                and Data Science. Pursuing BCA and BS in Data Science with a
                focus on delivering data-driven solutions.
              </p>
              <div className="footer-social-group">
                <a href="https://linkedin.com">
                  <div
                    aria-label="LinkedIn Profile"
                    className="footer-social-link"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                    >
                      <g
                        fill="none"
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      >
                        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2a2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6M2 9h4v12H2z"></path>
                        <circle cx="4" cy="4" r="2"></circle>
                      </g>
                    </svg>
                  </div>
                </a>
                <a href="https://github.com">
                  <div
                    aria-label="GitHub Profile"
                    className="footer-social-link"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                    >
                      <g
                        fill="none"
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      >
                        <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5c.08-1.25-.27-2.48-1-3.5c.28-1.15.28-2.35 0-3.5c0 0-1 0-3 1.5c-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.4 5.4 0 0 0 4 9c0 3.5 3 5.5 6 5.5c-.39.49-.68 1.05-.85 1.65S8.93 17.38 9 18v4"></path>
                        <path d="M9 18c-4.51 2-5-2-7-2"></path>
                      </g>
                    </svg>
                  </div>
                </a>
                <a href="mailto:sinhamohit9870@gmail.com?subject=">
                  <div aria-label="Email Mohit" className="footer-social-link">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                    >
                      <g
                        fill="none"
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      >
                        <path d="m22 7l-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path>
                        <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                      </g>
                    </svg>
                  </div>
                </a>
              </div>
            </div>
            <div className="footer-column footer-nav">
              <h3 className="footer-heading section-subtitle">Navigation</h3>
              <nav className="footer-nav-list">
                <a href="#about">
                  <div className="footer-link">
                    <span>About</span>
                  </div>
                </a>
                <a href="#skills">
                  <div className="footer-link">
                    <span>Skills</span>
                  </div>
                </a>
                <a href="#projects">
                  <div className="footer-link">
                    <span>Projects</span>
                  </div>
                </a>
                <a href="#certifications">
                  <div className="footer-link">
                    <span>Certifications</span>
                  </div>
                </a>
              </nav>
            </div>
            <div className="footer-column footer-contact">
              <h3 className="footer-heading section-subtitle">Get In Touch</h3>
              <p className="footer-contact-text section-content">
                Available for collaborations and professional opportunities in
                AI and Data Science.
              </p>
              <div className="footer-cta-wrapper">
                <a href="mailto:sinhamohit9870@gmail.com?subject=">
                  <div className="btn-md footer-email-btn btn btn-primary">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                    >
                      <g
                        fill="none"
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      >
                        <path d="m22 7l-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path>
                        <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                      </g>
                    </svg>
                    <span>
                      {' '}
                      Chat via Email
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </div>
                </a>
              </div>
            </div>
          </div>
          <div className="footer-bottom">
            <div className="footer-copyright">
              <span className="section-content">
                &amp;copy; 2025 Mohit Sinha Portfolio. All rights reserved.
              </span>
            </div>
            <div className="footer-legal-links">
              <a href="#">
                <div className="footer-link-sm">
                  <span>Privacy Policy</span>
                </div>
              </a>
              <a href="#">
                <div className="footer-link-sm">
                  <span>Terms of Service</span>
                </div>
              </a>
            </div>
          </div>
        </div>
      </footer>
      <div className="footer-container2">
        <div className="footer-container3">
          <Script
            html={`<script defer data-name="footer-scroll-reveal">
(function(){
  const footerReveal = () => {
    const footerItems = document.querySelectorAll(".footer-column, .footer-bottom")

    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = "1"
          entry.target.style.transform = "translateY(0)"
          observer.unobserve(entry.target)
        }
      })
    }, observerOptions)

    footerItems.forEach((item, index) => {
      item.style.opacity = "0"
      item.style.transform = "translateY(20px)"
      item.style.transition = \`opacity 0.6s ease \${index * 0.1}s, transform 0.6s ease \${index * 0.1}s\`
      observer.observe(item)
    })
  }

  footerReveal()
})()
</script>`}
          ></Script>
        </div>
      </div>
    </div>
  )
}

export default Footer
