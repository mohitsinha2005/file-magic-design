import React from 'react'

import Script from 'dangerous-html/react'

import './navigation.css'

const Navigation = (props) => {
  return (
    <div className="navigation-container1">
      <nav className="navigation-wrapper">
        <div className="navigation-container">
          <a href="/">
            <div
              aria-label="Mohit Sinha Portfolio Home"
              className="navigation-brand"
            >
              <span className="section-title">Mohit Sinha</span>
            </div>
          </a>
          <div className="navigation-links-desktop">
            <a href="#about">
              <div className="navigation-link">
                <span>About</span>
              </div>
            </a>
            <a href="#skills">
              <div className="navigation-link">
                <span>Skills</span>
              </div>
            </a>
            <a href="#projects">
              <div className="navigation-link">
                <span>Projects</span>
              </div>
            </a>
            <a href="#certifications">
              <div className="navigation-link">
                <span>Certifications</span>
              </div>
            </a>
            <a href="mailto:sinhamohit9870@gmail.com?subject=">
              <div className="navigation-cta btn btn-primary btn-sm">
                <span>Chat via Email</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                >
                  <path d="M5 12h14m-7-7l7 7l-7 7"></path>
                </svg>
              </div>
            </a>
          </div>
          <button
            id="navToggle"
            aria-label="Open Menu"
            aria-expanded="false"
            className="navigation-mobile-toggle"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
            >
              <path d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>
      </nav>
      <div id="mobileOverlay" className="navigation-mobile-overlay">
        <div className="navigation-mobile-header">
          <a href="/">
            <div
              aria-label="Mohit Sinha Portfolio Home"
              className="navigation-brand"
            >
              <span className="section-title">Mohit Sinha</span>
            </div>
          </a>
          <button
            id="navClose"
            aria-label="Close Menu"
            className="navigation-mobile-close"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
            >
              <path d="M18 6L6 18M6 6l12 12"></path>
            </svg>
          </button>
        </div>
        <div className="navigation-mobile-content">
          <div className="navigation-mobile-links">
            <a href="#about">
              <div className="navigation-mobile-link">
                <span>About</span>
              </div>
            </a>
            <a href="#skills">
              <div className="navigation-mobile-link">
                <span>Skills</span>
              </div>
            </a>
            <a href="#projects">
              <div className="navigation-mobile-link">
                <span>Projects</span>
              </div>
            </a>
            <a href="#certifications">
              <div className="navigation-mobile-link">
                <span>Certifications</span>
              </div>
            </a>
          </div>
          <div className="navigation-mobile-footer">
            <a href="mailto:sinhamohit9870@gmail.com?subject=">
              <div className="navigation-cta-mobile btn btn-primary btn-lg">
                <span>Chat via Email</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                >
                  <path d="M5 12h14m-7-7l7 7l-7 7"></path>
                </svg>
              </div>
            </a>
          </div>
        </div>
      </div>
      <div className="navigation-container2">
        <div className="navigation-container3">
          <Script
            html={`<style>
@media (prefers-reduced-motion: reduce) {
.navigation-mobile-overlay {
  transition: none;
}
}
</style>`}
          ></Script>
        </div>
      </div>
      <div className="navigation-container4">
        <div className="navigation-container5">
          <Script
            html={`<script defer data-name="navigation-logic">
(function(){
  const navToggle = document.getElementById("navToggle")
  const navClose = document.getElementById("navClose")
  const mobileOverlay = document.getElementById("mobileOverlay")
  const mobileLinks = document.querySelectorAll(".navigation-mobile-link")

  const openMenu = () => {
    mobileOverlay.classList.add("is-active")
    navToggle.setAttribute("aria-expanded", "true")
    document.body.style.overflow = "hidden"
  }

  const closeMenu = () => {
    mobileOverlay.classList.remove("is-active")
    navToggle.setAttribute("aria-expanded", "false")
    document.body.style.overflow = ""
  }

  navToggle.addEventListener("click", openMenu)
  navClose.addEventListener("click", closeMenu)

  mobileLinks.forEach((link) => {
    link.addEventListener("click", closeMenu)
  })

  window.addEventListener("resize", () => {
    if (window.innerWidth > 767 && mobileOverlay.classList.contains("is-active")) {
      closeMenu()
    }
  })

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && mobileOverlay.classList.contains("is-active")) {
      closeMenu()
    }
  })
})()
</script>`}
          ></Script>
        </div>
      </div>
    </div>
  )
}

export default Navigation
