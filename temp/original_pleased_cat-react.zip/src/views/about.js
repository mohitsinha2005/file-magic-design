import React from 'react'

import Script from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import Navigation from '../components/navigation'
import Footer from '../components/footer'
import './about.css'

const About = (props) => {
  return (
    <div className="about-container1">
      <Helmet>
        <title>About - Original Pleased Cat</title>
        <meta property="og:title" content="About - Original Pleased Cat" />
        <link
          rel="canonical"
          href="https://original-pleased-cat-kpua81.teleporthq.app/about"
        />
      </Helmet>
      <Navigation></Navigation>
      <main>
        <section className="about-hero-section">
          <div className="about-hero-container">
            <div className="about-hero-content">
              <span className="hero-badge">
                AI &amp; Data Science Professional
              </span>
              <h1 className="about-hero-title hero-title">Mohit Sinha</h1>
              <p className="hero-subtitle">
                BCA &amp; BS in Data Science Candidate
              </p>
              <p className="about-hero-summary section-content">
                Driving innovation through data-driven insights and artificial
                intelligence. Specialized in building scalable machine learning
                models and robust data architectures for modern enterprise
                challenges.
              </p>
              <div className="about-hero-actions">
                <a href="#contact">
                  <div className="about-btn btn btn-primary">
                    <span>Connect for Opportunities</span>
                  </div>
                </a>
                <a href="#projects">
                  <div className="about-btn btn btn-outline">
                    <span>View Portfolio</span>
                  </div>
                </a>
              </div>
            </div>
            <div className="hero-visual">
              <div className="about-hero-image-wrapper">
                <img
                  src="https://images.pexels.com/photos/18360995/pexels-photo-18360995.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  alt="Mohit Sinha Profile"
                  className="about-hero-image"
                />
                <div className="hero-image-overlay"></div>
              </div>
            </div>
          </div>
        </section>
        <section className="about-about-section">
          <div className="about-container">
            <div className="about-card">
              <div className="about-header">
                <h2 className="section-title">Professional Biography</h2>
                <p className="section-subtitle">
                  Bridging Logic and Intelligence
                </p>
              </div>
              <div className="about-body">
                <p className="section-content">
                  As a technology professional deeply immersed in the dual
                  pursuit of Computer Applications and Data Science, I
                  specialize in the intersection of software engineering and
                  advanced analytics. My approach is rooted in structural logic
                  and mathematical precision, focusing on creating AI-driven
                  solutions that translate complex data into actionable business
                  intelligence.
                </p>
                <p className="section-content">
                  I am committed to a philosophy of continuous optimization.
                  Whether developing predictive models or architecting database
                  systems, my objective remains consistent: to build
                  high-performance, recruiter-ready technologies that meet the
                  rigorous standards of today&apos;s corporate landscape.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="edu-section">
          <div className="edu-container">
            <div className="edu-header">
              <h2 className="section-title">Academic Qualifications</h2>
              <p className="section-subtitle">
                Foundational Excellence in Technology
              </p>
            </div>
            <div className="timeline-wrapper">
              <div className="timeline-item">
                <div className="timeline-marker">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <circle cx="12" cy="12" r="1"></circle>
                    </g>
                  </svg>
                </div>
                <div className="timeline-content">
                  <span className="timeline-date">Expected 2026</span>
                  <h3 className="timeline-title">BS in Data Science</h3>
                  <p className="timeline-org">
                    Indian Institute of Technology (IIT) Madras
                  </p>
                  <p className="section-content">
                    Advanced specialization in Machine Learning, Statistical
                    Inference, and Big Data Analytics. Notable project:
                    Predictive Modeling for Financial Markets.
                  </p>
                </div>
              </div>
              <div className="timeline-item">
                <div className="timeline-marker">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <circle cx="12" cy="12" r="1"></circle>
                    </g>
                  </svg>
                </div>
                <div className="timeline-content">
                  <span className="timeline-date">2022 - 2025</span>
                  <h3 className="timeline-title">
                    Bachelor of Computer Applications (BCA)
                  </h3>
                  <p className="timeline-org">University of Delhi</p>
                  <p className="section-content">
                    Core computer science curriculum including Data Structures,
                    Algorithms, and Software Engineering. Focused on full-stack
                    development and system architecture.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="focus-section">
          <div className="focus-container">
            <div className="focus-header">
              <h2 className="section-title">Strategic Specialization</h2>
              <p className="section-subtitle">
                Targeted expertise for enterprise impact
              </p>
            </div>
            <div className="focus-grid">
              <div className="focus-card">
                <div className="focus-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <path
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m16 18l6-6l-6-6M8 6l-6 6l6 6"
                    ></path>
                  </svg>
                </div>
                <h3 className="focus-title">AI Integration</h3>
                <p className="section-content">
                  Implementing large language models and neural networks to
                  automate complex business workflows.
                </p>
              </div>
              <div className="focus-card">
                <div className="focus-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
                      <path d="M3 5v14a9 3 0 0 0 18 0V5"></path>
                      <path d="M3 12a9 3 0 0 0 18 0"></path>
                    </g>
                  </svg>
                </div>
                <h3 className="focus-title">Predictive Analytics</h3>
                <p className="section-content">
                  Utilizing statistical algorithms to identify the likelihood of
                  future outcomes based on historical data.
                </p>
              </div>
              <div className="focus-card">
                <div className="focus-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <path d="M3 3v16a2 2 0 0 0 2 2h16"></path>
                      <path d="m19 9l-5 5l-4-4l-3 3"></path>
                    </g>
                  </svg>
                </div>
                <h3 className="focus-title">Data Visualization</h3>
                <p className="section-content">
                  Crafting intuitive dashboards in Tableau and PowerBI to
                  communicate complex insights to stakeholders.
                </p>
              </div>
              <div className="focus-card">
                <div className="focus-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="M8 12h8m-4-4v8"></path>
                    </g>
                  </svg>
                </div>
                <h3 className="focus-title">MLOps</h3>
                <p className="section-content">
                  Streamlining the deployment and monitoring of machine learning
                  models in production environments.
                </p>
              </div>
              <div className="focus-card">
                <div className="focus-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <path d="M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z"></path>
                      <path d="M21.21 15.89A10 10 0 1 1 8 2.83"></path>
                    </g>
                  </svg>
                </div>
                <h3 className="focus-title">Big Data Engineering</h3>
                <p className="section-content">
                  Designing robust ETL pipelines and managing large-scale
                  distributed database systems.
                </p>
              </div>
              <div className="focus-card">
                <div className="focus-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <path d="M11.051 7.616a1 1 0 0 1 1.909.024l.737 1.452a1 1 0 0 0 .737.535l1.634.256a1 1 0 0 1 .588 1.806l-1.172 1.168a1 1 0 0 0-.282.866l.259 1.613a1 1 0 0 1-1.541 1.134l-1.465-.75a1 1 0 0 0-.912 0l-1.465.75a1 1 0 0 1-1.539-1.133l.258-1.613a1 1 0 0 0-.282-.867l-1.156-1.152a1 1 0 0 1 .572-1.822l1.633-.256a1 1 0 0 0 .737-.535z"></path>
                      <circle cx="12" cy="12" r="10"></circle>
                    </g>
                  </svg>
                </div>
                <h3 className="focus-title">Technical Strategy</h3>
                <p className="section-content">
                  Aligning technical capabilities with organizational goals to
                  drive competitive advantage.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="showcase-section">
          <div className="showcase-container">
            <div className="showcase-header">
              <h2 className="section-title">Key Achievements</h2>
              <p className="section-subtitle">
                Measurable results and professional milestones
              </p>
            </div>
            <div className="showcase-grid">
              <div className="showcase-item">
                <div className="showcase-image-box">
                  <img
                    src="https://images.pexels.com/photos/6476365/pexels-photo-6476365.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    alt="Project Achievement"
                    className="showcase-img"
                  />
                </div>
                <div className="showcase-content">
                  <h3 className="showcase-title">ML Optimization</h3>
                  <p className="section-content">
                    Achieved 94% accuracy in a classification model for
                    predictive maintenance.
                  </p>
                </div>
              </div>
              <div className="showcase-item">
                <div className="showcase-image-box">
                  <img
                    src="https://images.pexels.com/photos/6894208/pexels-photo-6894208.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    alt="Academic Achievement"
                    className="showcase-img"
                  />
                </div>
                <div className="showcase-content">
                  <h3 className="showcase-title">IIT Madras Honors</h3>
                  <p className="section-content">
                    Top 5% performer in the foundational Data Science cohort.
                  </p>
                </div>
              </div>
              <div className="showcase-item">
                <div className="showcase-image-box">
                  <img
                    src="https://images.pexels.com/photos/5301744/pexels-photo-5301744.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    alt="Competition Achievement"
                    className="showcase-img"
                  />
                </div>
                <div className="showcase-content">
                  <h3 className="showcase-title">Hackathon Winner</h3>
                  <p className="section-content">
                    1st Place in Regional AI for Social Good Hackathon 2023.
                  </p>
                </div>
              </div>
              <div className="showcase-item">
                <div className="showcase-image-box">
                  <img
                    src="https://images.pexels.com/photos/6893955/pexels-photo-6893955.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    alt="Certification Achievement"
                    className="showcase-img"
                  />
                </div>
                <div className="showcase-content">
                  <h3 className="showcase-title">Google Data Analytics</h3>
                  <p className="section-content">
                    Professional certification with 100% completion in advanced
                    SQL.
                  </p>
                </div>
              </div>
              <div className="showcase-item">
                <div className="showcase-image-box">
                  <img
                    src="https://images.pexels.com/photos/7984730/pexels-photo-7984730.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    alt="Research Achievement"
                    className="showcase-img"
                  />
                </div>
                <div className="showcase-content">
                  <h3 className="showcase-title">Research Publication</h3>
                  <p className="section-content">
                    Co-authored paper on Efficient Neural Architectures for IoT.
                  </p>
                </div>
              </div>
              <div className="showcase-item">
                <div className="showcase-image-box">
                  <img
                    src="https://images.pexels.com/photos/5717640/pexels-photo-5717640.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    alt="Community Achievement"
                    className="showcase-img"
                  />
                </div>
                <div className="showcase-content">
                  <h3 className="showcase-title">Open Source Lead</h3>
                  <p className="section-content">
                    Maintainer of a Python library for automated data cleaning.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="about-skills-section">
          <div className="skills-container">
            <div className="about-skills-header">
              <h2 className="section-title">Technical Proficiency</h2>
              <p className="section-subtitle">
                A comprehensive stack for the data-driven era
              </p>
            </div>
            <div className="about-skills-grid">
              <div className="about-skill-card">
                <div className="skill-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="m15 9l-6 6m0-6l6 6"></path>
                    </g>
                  </svg>
                </div>
                <h3 className="skill-title">Data Science &amp; ML</h3>
                <p className="section-content">
                  Python, Scikit-learn, TensorFlow, PyTorch, Pandas, NumPy.
                </p>
              </div>
              <div className="about-skill-card">
                <div className="skill-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
                      <path d="M3 5v14a9 3 0 0 0 18 0V5"></path>
                      <path d="M3 12a9 3 0 0 0 18 0"></path>
                    </g>
                  </svg>
                </div>
                <h3 className="skill-title">Database Management</h3>
                <p className="section-content">
                  SQL (PostgreSQL, MySQL), NoSQL (MongoDB), Data Warehousing.
                </p>
              </div>
              <div className="about-skill-card">
                <div className="skill-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <path
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M3 3v16a2 2 0 0 0 2 2h16M7 16h8m-8-5h12M7 6h3"
                    ></path>
                  </svg>
                </div>
                <h3 className="skill-title">Business Intelligence</h3>
                <p className="section-content">
                  Tableau, Microsoft Excel (Advanced), PowerBI, Data
                  Storytelling.
                </p>
              </div>
              <div className="about-skill-card">
                <div className="skill-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <path
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m16 18l6-6l-6-6M8 6l-6 6l6 6"
                    ></path>
                  </svg>
                </div>
                <h3 className="skill-title">Web Technologies</h3>
                <p className="section-content">
                  React.js, HTML5, CSS3, JavaScript (ES6+), RESTful APIs.
                </p>
              </div>
              <div className="about-skill-card">
                <div className="skill-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <path d="M10 14.66v1.626a2 2 0 0 1-.976 1.696A5 5 0 0 0 7 21.978m7-7.318v1.626a2 2 0 0 0 .976 1.696A5 5 0 0 1 17 21.978M18 9h1.5a1 1 0 0 0 0-5H18M4 22h16"></path>
                      <path d="M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1zm0 0H4.5a1 1 0 0 1 0-5H6"></path>
                    </g>
                  </svg>
                </div>
                <h3 className="skill-title">Software Engineering</h3>
                <p className="section-content">
                  Git, Version Control, Agile Methodologies, Software Design
                  Patterns.
                </p>
              </div>
              <div className="about-skill-card">
                <div className="skill-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <circle cx="12" cy="10" r="3"></circle>
                      <path d="M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662"></path>
                    </g>
                  </svg>
                </div>
                <h3 className="skill-title">AI Ethics &amp; Strategy</h3>
                <p className="section-content">
                  Bias mitigation, algorithmic transparency, and ROI-driven AI
                  implementation.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section id="contact" className="contact-section">
          <div className="contact-container">
            <div className="contact-card">
              <div className="contact-info">
                <h2 className="section-title">Initiate Collaboration</h2>
                <p className="section-subtitle">
                  Available for roles in AI, Data Science, and Software
                  Development.
                </p>
                <p className="contact-email">sinhamohit9870@gmail.com</p>
              </div>
              <div className="contact-actions">
                <a href="mailto:sinhamohit9870@gmail.com?subject=">
                  <div className="about-btn btn btn-accent btn-lg">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                    >
                      <g
                        fill="none"
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      >
                        <path d="m22 7l-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path>
                        <rect width="20" height="16" x="2" y="4" rx="2"></rect>
                      </g>
                    </svg>
                    <span>
                      {' '}
                      Chat via Email
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>
      <div className="about-container3">
        <div className="about-container4">
          <Script
            html={`<style>
main {
  background-color: var(--color-surface);
  color: var(--color-on-surface);
}
</style>`}
          ></Script>
        </div>
      </div>
      <div className="about-container5">
        <div className="about-container6">
          <Script
            html={`<script defer data-name="portfolio-interactions">
(function(){
  // Subtle scroll reveal animation for cards
  const revealOnScroll = () => {
    const elements = document.querySelectorAll(".focus-card, .skill-card, .showcase-item, .timeline-item")

    elements.forEach((el) => {
      const rect = el.getBoundingClientRect()
      const isVisible = rect.top <= window.innerHeight * 0.85

      if (isVisible) {
        el.style.opacity = "1"
        el.style.transform = "translateY(0)"
      }
    })
  }

  // Set initial styles for reveal
  const setupReveals = () => {
    const elements = document.querySelectorAll(".focus-card, .skill-card, .showcase-item, .timeline-item")
    elements.forEach((el) => {
      el.style.opacity = "0"
      el.style.transform = "translateY(20px)"
      el.style.transition = "all 0.6s ease-out"
    })

    // Initial check
    revealOnScroll()
  }

  window.addEventListener("scroll", revealOnScroll)
  setupReveals()

  // Parallax effect for hero image
  window.addEventListener("scroll", () => {
    const heroImage = document.querySelector(".hero-image")
    if (heroImage) {
      const scroll = window.pageYOffset
      heroImage.style.transform = \`translateY(\${scroll * 0.1}px) scale(\${1 + scroll * 0.0001})\`
    }
  })
})()
</script>`}
          ></Script>
        </div>
      </div>
      <Footer></Footer>
      <a href="https://play.teleporthq.io/signup">
        <div aria-label="Sign up to TeleportHQ" className="about-container7">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="about-icon67"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="about-text4">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default About
