import React from 'react'

import Script from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import Navigation from '../components/navigation'
import Footer from '../components/footer'
import './skills.css'

const Skills = (props) => {
  return (
    <div className="skills-container1">
      <Helmet>
        <title>Skills - Original Pleased Cat</title>
        <meta property="og:title" content="Skills - Original Pleased Cat" />
        <link
          rel="canonical"
          href="https://original-pleased-cat-kpua81.teleporthq.app/skills"
        />
      </Helmet>
      <Navigation></Navigation>
      <section className="skills-hero-section">
        <div className="skills-hero-container">
          <div className="hero-content">
            <div className="hero-text-wrapper">
              <h1 className="skills-hero-title hero-title">Mohit Sinha</h1>
              <p className="hero-subtitle">
                Technology Professional specializing in Artificial Intelligence
                &amp; Data Science.
              </p>
              <p className="hero-description section-content">
                Pursuing BCA and BS in Data Science with a focus on building
                recruiter-ready, corporate-grade solutions. Expert in Python,
                SQL, and Machine Learning architectures.
              </p>
              <div className="hero-cta-group">
                <a href="mailto:sinhamohit9870@gmail.com?subject=">
                  <div className="btn btn-primary btn-lg">
                    <span>Chat via Email</span>
                  </div>
                </a>
                <a href="#skills">
                  <div className="btn btn-lg btn-outline">
                    <span>View Competencies</span>
                  </div>
                </a>
              </div>
            </div>
            <div className="hero-visual-wrapper">
              <div className="skills-hero-image-frame">
                <img
                  src="https://images.pexels.com/photos/7989025/pexels-photo-7989025.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  alt="Mohit Sinha Portfolio"
                  className="hero-profile-image"
                />
                <div className="hero-floating-badge">
                  <span className="badge-text">Available for Hire</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="skills" className="skills-grid-section">
        <div className="skills-container">
          <h2 className="section-title">Technical Competencies</h2>
          <p className="section-subtitle">
            A comprehensive overview of core technical proficiencies and
            expertise levels.
          </p>
          <div className="skills-skills-grid">
            <div className="skills-skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="m16 18l6-6l-6-6M8 6l-6 6l6 6"
                  ></path>
                </svg>
              </div>
              <h3 className="skills-skill-name">Python</h3>
              <div className="skill-level-bar">
                <div className="skills-thq-skill-progress-elm1 skill-progress"></div>
              </div>
              <span className="skill-meta">Expert • 3+ Years</span>
            </div>
            <div className="skills-skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  >
                    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
                    <path d="M3 5v14a9 3 0 0 0 18 0V5"></path>
                    <path d="M3 12a9 3 0 0 0 18 0"></path>
                  </g>
                </svg>
              </div>
              <h3 className="skills-skill-name">SQL</h3>
              <div className="skill-level-bar">
                <div className="skills-thq-skill-progress-elm2 skill-progress"></div>
              </div>
              <span className="skill-meta">Advanced • 2 Years</span>
            </div>
            <div className="skills-skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  >
                    <path d="M12 18V5m3 8a4.17 4.17 0 0 1-3-4a4.17 4.17 0 0 1-3 4m8.598-6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5"></path>
                    <path d="M17.997 5.125a4 4 0 0 1 2.526 5.77"></path>
                    <path d="M18 18a4 4 0 0 0 2-7.464"></path>
                    <path d="M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517"></path>
                    <path d="M6 18a4 4 0 0 1-2-7.464"></path>
                    <path d="M6.003 5.125a4 4 0 0 0-2.526 5.77"></path>
                  </g>
                </svg>
              </div>
              <h3 className="skills-skill-name">Machine Learning</h3>
              <div className="skill-level-bar">
                <div className="skills-thq-skill-progress-elm3 skill-progress"></div>
              </div>
              <span className="skill-meta">Advanced • 2 Years</span>
            </div>
            <div className="skills-skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  >
                    <path d="M3 3v16a2 2 0 0 0 2 2h16"></path>
                    <path d="m19 9l-5 5l-4-4l-3 3"></path>
                  </g>
                </svg>
              </div>
              <h3 className="skills-skill-name">Data Science</h3>
              <div className="skill-level-bar">
                <div className="skills-thq-skill-progress-elm4 skill-progress"></div>
              </div>
              <span className="skill-meta">Intermediate • 2 Years</span>
            </div>
            <div className="skills-skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  >
                    <path d="M6.306 8.711C3.704 9.434 2 10.637 2 12c0 2.21 4.477 4 10 4c.773 0 1.526-.035 2.248-.102m3.444-.609C20.295 14.567 22 13.363 22 12c0-2.21-4.477-4-10-4c-.773 0-1.526.035-2.25.102"></path>
                    <path d="M6.305 15.287C5.629 17.902 5.82 19.98 7 20.66c1.913 1.105 5.703-1.877 8.464-6.66q.581-1.007 1.036-2m1.194-3.284C18.371 6.1 18.181 4.02 17 3.34C15.087 2.235 11.297 5.217 8.536 10c-.387.67-.733 1.34-1.037 2"></path>
                    <path d="M12 5.424C10.075 3.532 8.18 2.658 7 3.34C5.087 4.444 5.774 9.217 8.536 14c.386.67.793 1.304 1.212 1.896M12 18.574c1.926 1.893 3.821 2.768 5 2.086c1.913-1.104 1.226-5.877-1.536-10.66q-.563-.976-1.212-1.897M11.5 12.866a1 1 0 1 0 1-1.732a1 1 0 0 0-1 1.732"></path>
                  </g>
                </svg>
              </div>
              <h3 className="skills-skill-name">React &amp; Web</h3>
              <div className="skill-level-bar">
                <div className="skills-thq-skill-progress-elm5 skill-progress"></div>
              </div>
              <span className="skill-meta">Intermediate • 1 Year</span>
            </div>
            <div className="skills-skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  >
                    <circle cx="12" cy="18" r="3"></circle>
                    <circle cx="6" cy="6" r="3"></circle>
                    <circle cx="18" cy="6" r="3"></circle>
                    <path d="M18 9v2c0 .6-.4 1-1 1H7c-.6 0-1-.4-1-1V9m6 3v3"></path>
                  </g>
                </svg>
              </div>
              <h3 className="skills-skill-name">Git &amp; DevOps</h3>
              <div className="skill-level-bar">
                <div className="skills-thq-skill-progress-elm6 skill-progress"></div>
              </div>
              <span className="skill-meta">Advanced • 2 Years</span>
            </div>
          </div>
        </div>
      </section>
      <section className="capabilities-section">
        <div className="capabilities-container">
          <h2 className="section-title">Core Capabilities</h2>
          <p className="section-subtitle">
            High-impact specializations that drive professional value.
          </p>
          <div className="capabilities-grid">
            <div className="capability-card">
              <h3 className="section-subtitle">Model Development</h3>
              <p className="section-content">
                Designing and deploying predictive models using advanced ML
                algorithms to solve complex business challenges.
              </p>
            </div>
            <div className="capability-card">
              <h3 className="section-subtitle">Data Engineering</h3>
              <p className="section-content">
                Building robust ETL pipelines and managing large-scale SQL
                databases for seamless data flow and integrity.
              </p>
            </div>
            <div className="capability-card">
              <h3 className="section-subtitle">Visual Analytics</h3>
              <p className="section-content">
                Transforming raw data into actionable insights through
                high-fidelity Tableau and Excel executive dashboards.
              </p>
            </div>
            <div className="capability-card">
              <h3 className="section-subtitle">Web Integration</h3>
              <p className="section-content">
                Bridging the gap between data and users by developing
                React-based interfaces for data-driven applications.
              </p>
            </div>
            <div className="capability-card">
              <h3 className="section-subtitle">AI Optimization</h3>
              <p className="section-content">
                Implementing state-of-the-art AI techniques to enhance automated
                decision-making and operational efficiency.
              </p>
            </div>
            <div className="capability-card">
              <h3 className="section-subtitle">Technical Leadership</h3>
              <p className="section-content">
                Managing version control and collaborative workflows to ensure
                high-quality software delivery.
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="mapping-section">
        <div className="mapping-container">
          <h2 className="section-title">Skill-to-Impact Mapping</h2>
          <div className="mapping-table-wrapper">
            <table className="mapping-table">
              <thead>
                <tr>
                  <th>
                    <span>Core Skill</span>
                  </th>
                  <th>
                    <span>Practical Application</span>
                  </th>
                  <th>
                    <span>Project Artifact</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="skill-label">
                    <span>Python</span>
                  </td>
                  <td>
                    <span>Automated ETL processes and script optimization</span>
                  </td>
                  <td>
                    <a href="#">
                      <div className="btn-link">
                        <span>Data Pipeline v2</span>
                      </div>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td className="skill-label">
                    <span>Tableau</span>
                  </td>
                  <td>
                    <span>
                      Executive-level financial performance dashboards
                    </span>
                  </td>
                  <td>
                    <a href="#">
                      <div className="btn-link">
                        <span>Global Sales View</span>
                      </div>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td className="skill-label">
                    <span>SQL</span>
                  </td>
                  <td>
                    <span>Complex query design for real-time reporting</span>
                  </td>
                  <td>
                    <a href="#">
                      <div className="btn-link">
                        <span>DBMS Optimization</span>
                      </div>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td className="skill-label">
                    <span>React</span>
                  </td>
                  <td>
                    <span>
                      Building interactive data visualization components
                    </span>
                  </td>
                  <td>
                    <a href="#">
                      <div className="btn-link">
                        <span>Insights Portal</span>
                      </div>
                    </a>
                  </td>
                </tr>
                <tr>
                  <td className="skill-label">
                    <span>ML/AI</span>
                  </td>
                  <td>
                    <span>Deployment of customer churn prediction models</span>
                  </td>
                  <td>
                    <a href="#">
                      <div className="btn-link">
                        <span>Predictive Engine</span>
                      </div>
                    </a>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
      <section className="timeline-section">
        <div className="timeline-container">
          <h2 className="section-title">Professional Growth</h2>
          <div className="timeline-vertical">
            <div className="skills-timeline-item">
              <div className="skills-timeline-marker"></div>
              <div className="timeline-content">
                <span className="timeline-date">2024 - Present</span>
                <h3 className="section-subtitle">
                  BS in Data Science (IIT Madras)
                </h3>
                <p className="section-content">
                  Focusing on advanced statistical modeling, machine learning
                  operations, and large-scale data systems.
                </p>
              </div>
            </div>
            <div className="skills-timeline-item">
              <div className="skills-timeline-marker"></div>
              <div className="timeline-content">
                <span className="timeline-date">2023</span>
                <h3 className="section-subtitle">BCA Specialization</h3>
                <p className="section-content">
                  Deep dive into software engineering principles, database
                  management, and web architecture.
                </p>
              </div>
            </div>
            <div className="skills-timeline-item">
              <div className="skills-timeline-marker"></div>
              <div className="timeline-content">
                <span className="timeline-date">2022</span>
                <h3 className="section-subtitle">
                  Full-Stack Development Certification
                </h3>
                <p className="section-content">
                  Mastered modern web technologies (HTML, CSS, React) and
                  Git-based collaborative development.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="process-section">
        <div className="process-container">
          <h2 className="section-title">Workflow &amp; Process</h2>
          <div className="steps-horizontal">
            <div className="step-item">
              <div className="step-number">
                <span>01</span>
              </div>
              <h3 className="step-title">Data Ingestion</h3>
              <p className="section-content">
                Connecting to diverse sources via SQL and Python-based ETL
                scripts.
              </p>
            </div>
            <div className="step-item">
              <div className="step-number">
                <span>02</span>
              </div>
              <h3 className="step-title">Model Training</h3>
              <p className="section-content">
                Applying ML algorithms to identify patterns and train predictive
                engines.
              </p>
            </div>
            <div className="step-item">
              <div className="step-number">
                <span>03</span>
              </div>
              <h3 className="step-title">Visualization</h3>
              <p className="section-content">
                Creating interactive Tableau dashboards for stakeholder
                communication.
              </p>
            </div>
            <div className="step-item">
              <div className="step-number">
                <span>04</span>
              </div>
              <h3 className="step-title">Deployment</h3>
              <p className="section-content">
                Integrating results into React apps using Git-based CI/CD
                pipelines.
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="skills-cta-section">
        <div className="cta-container">
          <div className="skills-cta-card">
            <h2 className="section-title">Let&apos;s Build Something Great</h2>
            <p className="section-content">
              Currently open to professional opportunities in Data Science, AI,
              and Software Development.
            </p>
            <div className="skills-cta-actions">
              <a href="mailto:sinhamohit9870@gmail.com?subject=">
                <div className="btn btn-accent btn-xl">
                  <span>Chat via Email</span>
                </div>
              </a>
            </div>
            <p className="availability-note">
              Response time: Usually within 24 hours.
            </p>
          </div>
        </div>
      </section>
      <div className="skills-container2">
        <div className="skills-container3">
          <Script
            html={`<script defer data-name="skills-page-interactions">
(function(){
  // Intersection Observer for scroll animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1"
        entry.target.style.transform = "translateY(0)"
        revealObserver.unobserve(entry.target)
      }
    })
  }, observerOptions)

  // Apply initial states and observe elements
  document.querySelectorAll(".skill-card, .capability-card, .timeline-item, .step-item").forEach((el) => {
    el.style.opacity = "0"
    el.style.transform = "translateY(20px)"
    el.style.transition = "all 0.6s ease-out"
    revealObserver.observe(el)
  })

  // Staggered reveal for skill cards
  document.querySelectorAll(".skills-grid").forEach((grid) => {
    const cards = grid.querySelectorAll(".skill-card")
    cards.forEach((card, index) => {
      card.style.transitionDelay = \`\${index * 100}ms\`
    })
  })

  // Add hover effect to table rows
  document.querySelectorAll(".mapping-table tr").forEach((row) => {
    row.addEventListener("mouseenter", () => {
      row.style.backgroundColor = "color-mix(in srgb, var(--color-accent) 5%, transparent)"
    })
    row.addEventListener("mouseleave", () => {
      row.style.backgroundColor = "transparent"
    })
  })
})()
</script>`}
          ></Script>
        </div>
      </div>
      <Footer></Footer>
      <a href="https://play.teleporthq.io/signup">
        <div aria-label="Sign up to TeleportHQ" className="skills-container4">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="skills-icon40"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="skills-text35">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Skills
