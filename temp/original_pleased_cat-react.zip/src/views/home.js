import React from 'react'

import Script from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import Navigation from '../components/navigation'
import Footer from '../components/footer'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container1">
      <Helmet>
        <title>Original Pleased Cat</title>
        <meta property="og:title" content="Original Pleased Cat" />
        <link
          rel="canonical"
          href="https://original-pleased-cat-kpua81.teleporthq.app/"
        />
      </Helmet>
      <Navigation></Navigation>
      <section className="hero-section">
        <div className="hero-container">
          <div className="hero-content">
            <div className="hero-text-wrapper">
              <h1 className="home-hero-title hero-title">Mohit Sinha</h1>
              <p className="home-hero-subtitle hero-subtitle">
                Specialist in AI &amp; Data Science
              </p>
              <p className="hero-summary section-content">
                Aspiring Data Scientist and AI Researcher currently pursuing BCA
                and BS in Data Science. Dedicated to transforming complex data
                into actionable insights through Machine Learning, predictive
                modeling, and advanced analytics. Recruiter-ready professional
                with a focus on scalable AI solutions.
              </p>
              <div className="hero-actions">
                <a href="mailto:sinhamohit9870@gmail.com?subject=">
                  <div className="btn btn-primary">
                    <span>Chat via Email</span>
                  </div>
                </a>
                <div className="hero-anchor-links">
                  <a href="#about">
                    <div className="btn-link">
                      <span>About</span>
                    </div>
                  </a>
                  <a href="#skills">
                    <div className="btn-link">
                      <span>Skills</span>
                    </div>
                  </a>
                  <a href="#projects">
                    <div className="btn-link">
                      <span>Projects</span>
                    </div>
                  </a>
                  <a href="#certifications">
                    <div className="btn-link">
                      <span>Certifications</span>
                    </div>
                  </a>
                  <a href="#contact">
                    <div className="btn-link">
                      <span>Contact</span>
                    </div>
                  </a>
                </div>
              </div>
            </div>
            <div className="hero-image-wrapper">
              <div className="hero-image-frame">
                <img
                  src="https://images.pexels.com/photos/7989025/pexels-photo-7989025.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  alt="Mohit Sinha Professional Portrait"
                  className="hero-image"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="skills" className="skills-section">
        <div className="skills-container">
          <div className="skills-header">
            <h2 className="section-title">Core Technical Skills</h2>
            <p className="section-subtitle">
              Proficiency in modern data stack &amp; AI technologies
            </p>
          </div>
          <div className="skills-grid">
            <div className="skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 2H2v10h10V2z"></path>
                  <path d="M22 12H12v10h10V12z"></path>
                  <path d="M12 12H2v10h10V12z"></path>
                  <path d="M22 2H12v10h10V2z"></path>
                </svg>
              </div>
              <h3 className="skill-name">Python &amp; SQL</h3>
              <p className="section-content">
                Advanced scripting and complex database querying for data
                manipulation.
              </p>
              <div className="skill-meter">
                <div className="home-thq-skill-progress-elm1 skill-progress"></div>
              </div>
            </div>
            <div className="skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M12 16v-4"></path>
                  <path d="M12 8h.01"></path>
                </svg>
              </div>
              <h3 className="skill-name">Data Science</h3>
              <p className="section-content">
                Statistical analysis, EDA, and data cleaning using Pandas and
                NumPy.
              </p>
              <div className="skill-meter">
                <div className="home-thq-skill-progress-elm2 skill-progress"></div>
              </div>
            </div>
            <div className="skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                  <path d="M2 17l10 5 10-5"></path>
                  <path d="M2 12l10 5 10-5"></path>
                </svg>
              </div>
              <h3 className="skill-name">ML &amp; AI</h3>
              <p className="section-content">
                Building predictive models using Scikit-Learn, TensorFlow, and
                PyTorch.
              </p>
              <div className="skill-meter">
                <div className="home-thq-skill-progress-elm3 skill-progress"></div>
              </div>
            </div>
            <div className="skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M3 3v18h18"></path>
                  <path d="M18 17l-6-6-4 4-5-5"></path>
                </svg>
              </div>
              <h3 className="skill-name">Tableau &amp; Excel</h3>
              <p className="section-content">
                Interactive dashboards and advanced financial/data modeling.
              </p>
              <div className="skill-meter">
                <div className="home-thq-skill-progress-elm4 skill-progress"></div>
              </div>
            </div>
            <div className="skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M20 16V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v16l4-2 4 2 4-2 4 2z"></path>
                  <path d="M8 7h8"></path>
                  <path d="M8 11h8"></path>
                </svg>
              </div>
              <h3 className="skill-name">React &amp; Web</h3>
              <p className="section-content">
                Building responsive UI for data applications using HTML, CSS,
                and React.
              </p>
              <div className="skill-meter">
                <div className="home-thq-skill-progress-elm5 skill-progress"></div>
              </div>
            </div>
            <div className="skill-card">
              <div className="skill-icon-box">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m7 15 5 5 5-5"></path>
                  <path d="m7 9 5-5 5 5"></path>
                </svg>
              </div>
              <h3 className="skill-name">Git &amp; DevOps</h3>
              <p className="section-content">
                Version control and basic CI/CD pipelines for collaborative
                engineering.
              </p>
              <div className="skill-meter">
                <div className="home-thq-skill-progress-elm6 skill-progress"></div>
              </div>
            </div>
          </div>
          <div className="skills-footer">
            <a href="#">
              <div className="btn btn-outline">
                <span>View Full Skills Inventory</span>
              </div>
            </a>
          </div>
        </div>
      </section>
      <section id="projects" className="projects-section">
        <div className="projects-container">
          <div className="projects-header">
            <h2 className="section-title">Highlighted Projects</h2>
            <p className="section-subtitle">
              End-to-end data solutions and AI implementations
            </p>
          </div>
          <div className="projects-grid">
            <div className="project-card">
              <div className="project-image-container">
                <img
                  src="https://images.pexels.com/photos/7567528/pexels-photo-7567528.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  alt="Predictive Analytics Project"
                  className="project-img"
                />
                <div className="project-overlay">
                  <a href="#">
                    <div className="btn btn-sm btn-accent">
                      <span>View Case Study</span>
                    </div>
                  </a>
                </div>
              </div>
              <div className="project-details">
                <h3 className="project-name">Market Trend Predictor</h3>
                <p className="section-content">
                  AI-powered forecasting tool using LSTM networks to predict
                  stock market fluctuations with 89% accuracy.
                </p>
                <div className="project-tags">
                  <span className="tag">Python</span>
                  <span className="tag">TensorFlow</span>
                  <span className="tag">Finance</span>
                </div>
              </div>
            </div>
            <div className="project-card">
              <div className="project-image-container">
                <img
                  src="https://images.pexels.com/photos/5715844/pexels-photo-5715844.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  alt="Customer Segmentation Project"
                  className="project-img"
                />
                <div className="project-overlay">
                  <a href="#">
                    <div className="btn btn-sm btn-accent">
                      <span>View Case Study</span>
                    </div>
                  </a>
                </div>
              </div>
              <div className="project-details">
                <h3 className="project-name">Retail Insights Engine</h3>
                <p className="section-content">
                  Clustering analysis for a retail dataset to identify
                  high-value customer segments and optimize marketing spend.
                </p>
                <div className="project-tags">
                  <span className="tag">SQL</span>
                  <span className="tag">K-Means</span>
                  <span className="tag">Tableau</span>
                </div>
              </div>
            </div>
            <div className="project-card">
              <div className="project-image-container">
                <img
                  src="https://images.pexels.com/photos/5715859/pexels-photo-5715859.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  alt="Natural Language Processing Project"
                  className="project-img"
                />
                <div className="project-overlay">
                  <a href="#">
                    <div className="btn btn-sm btn-accent">
                      <span>View Case Study</span>
                    </div>
                  </a>
                </div>
              </div>
              <div className="project-details">
                <h3 className="project-name">Sentiment Analysis Bot</h3>
                <p className="section-content">
                  Real-time social media sentiment tracker using NLP to gauge
                  public opinion on emerging tech trends.
                </p>
                <div className="project-tags">
                  <span className="tag">NLP</span>
                  <span className="tag">Scikit-Learn</span>
                  <span className="tag">React</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="certifications" className="certifications-section">
        <div className="certifications-container">
          <div className="certifications-header">
            <h2 className="section-title">Professional Certifications</h2>
            <p className="section-subtitle">
              Validated expertise in Data Science and Artificial Intelligence
            </p>
          </div>
          <div className="certifications-grid">
            <div className="cert-item">
              <div className="cert-icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              </div>
              <div className="cert-info">
                <h3 className="cert-title">
                  Google Data Analytics Professional
                </h3>
                <p className="cert-meta">Google | 2024</p>
              </div>
            </div>
            <div className="cert-item">
              <div className="cert-icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              </div>
              <div className="cert-info">
                <h3 className="cert-title">Machine Learning Specialization</h3>
                <p className="cert-meta">Stanford Online | 2023</p>
              </div>
            </div>
            <div className="cert-item">
              <div className="cert-icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              </div>
              <div className="cert-info">
                <h3 className="cert-title">AI Foundations</h3>
                <p className="cert-meta">IBM | 2023</p>
              </div>
            </div>
            <div className="cert-item">
              <div className="cert-icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              </div>
              <div className="cert-info">
                <h3 className="cert-title">Tableau Desktop Specialist</h3>
                <p className="cert-meta">Tableau | 2024</p>
              </div>
            </div>
            <div className="cert-item">
              <div className="cert-icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              </div>
              <div className="cert-info">
                <h3 className="cert-title">Python for Data Science</h3>
                <p className="cert-meta">DataCamp | 2023</p>
              </div>
            </div>
            <div className="cert-item">
              <div className="cert-icon">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              </div>
              <div className="cert-info">
                <h3 className="cert-title">SQL Advanced certification</h3>
                <p className="cert-meta">HackerRank | 2024</p>
              </div>
            </div>
          </div>
          <div className="cert-footer">
            <a href="#">
              <div className="btn btn-link">
                <span>View All Certificates</span>
              </div>
            </a>
          </div>
        </div>
      </section>
      <section id="about" className="about-section">
        <div className="about-container">
          <div className="about-layout">
            <div className="about-content">
              <h2 className="section-title">Professional Profile</h2>
              <p className="section-content">
                <span>
                  {' '}
                  I am a dual-degree student pursuing a
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
                <span className="home-text22">BCA</span>
                <span>
                  {' '}
                  and a
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
                <span className="home-text24">BS in Data Science</span>
                <span>
                  {' '}
                  , creating a unique synergy between application development
                  and analytical depth. My focus lies at the intersection of
                  Artificial Intelligence and practical business intelligence.
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
              </p>
              <div className="about-details-list">
                <div className="about-detail-item">
                  <h4 className="detail-label">Specialization</h4>
                  <p className="section-content">
                    Predictive Modeling, Machine Learning Operations (MLOps),
                    and Data Visualization.
                  </p>
                </div>
                <div className="about-detail-item">
                  <h4 className="detail-label">Education</h4>
                  <p className="section-content">
                    BCA (Computer Applications) &amp; BS in Data Science
                    (Specializing in AI).
                  </p>
                </div>
                <div className="about-detail-item">
                  <h4 className="detail-label">Recruiter Focus</h4>
                  <p className="section-content">
                    Seeking opportunities to leverage data-driven strategies for
                    corporate growth and efficiency.
                  </p>
                </div>
              </div>
              <a href="#">
                <div className="btn btn-secondary">
                  <span>Learn More About My Journey</span>
                </div>
              </a>
            </div>
            <div className="about-visual">
              <div className="about-stats-card">
                <div className="stat-circle">
                  <span className="stat-number">AI</span>
                  <span className="stat-label">Core Focus</span>
                </div>
                <div className="stat-text">
                  <p className="section-content">
                    Dedicated to building ethical, scalable, and
                    high-performance AI systems.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="contact" className="cta-section">
        <div className="cta-container">
          <div className="cta-card">
            <div className="cta-content">
              <h2 className="section-title">Let&apos;s Connect</h2>
              <p className="section-content">
                Currently open to internship and junior-level opportunities in
                Data Science and AI research. I am available for immediate
                interviews and technical assessments.
              </p>
              <div className="cta-actions">
                <a href="mailto:sinhamohit9870@gmail.com?subject=">
                  <div className="btn btn-primary btn-lg">
                    <span>Chat via Email</span>
                  </div>
                </a>
                <a href="#">
                  <div className="btn btn-outline btn-lg">
                    <span>View Contact Details</span>
                  </div>
                </a>
              </div>
              <p className="cta-availability">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#22c55e"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10"></circle>
                </svg>
                <span>
                  {' '}
                  Available for new projects &amp; opportunities
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
              </p>
            </div>
          </div>
        </div>
      </section>
      <div className="home-container2">
        <div className="home-container3">
          <Script
            html={`<script defer data-name="portfolio-interactions">
(function(){
  const scrollReveal = () => {
    const elements = document.querySelectorAll(".skill-card, .project-card, .cert-item")
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = "1"
            entry.target.style.transform = "translateY(0)"
          }
        })
      },
      { threshold: 0.1 }
    )

    elements.forEach((el) => {
      el.style.opacity = "0"
      el.style.transform = "translateY(20px)"
      el.style.transition = "all 0.6s ease-out"
      observer.observe(el)
    })
  }

  const skillAnimation = () => {
    const progressBars = document.querySelectorAll(".skill-progress")
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const targetWidth = entry.target.style.width
            entry.target.style.width = "0"
            setTimeout(() => {
              entry.target.style.transition = "width 1.5s cubic-bezier(0.65, 0, 0.35, 1)"
              entry.target.style.width = targetWidth
            }, 100)
          }
        })
      },
      { threshold: 0.5 }
    )

    progressBars.forEach((bar) => observer.observe(bar))
  }

  scrollReveal()
  skillAnimation()
})()
</script>`}
          ></Script>
        </div>
      </div>
      <Footer></Footer>
      <a href="https://play.teleporthq.io/signup">
        <div aria-label="Sign up to TeleportHQ" className="home-container4">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="home-icon47"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="home-text30">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Home
